const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Configuración de conexión a MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',        
  password: '',        
  database: 'contratos_db'
});

// Conectar a la base
db.connect(err => {
  if (err) {
    console.error('❌ Error de conexión a la BD:', err);
    return;
  }
  console.log('✅ Conectado a MySQL');
});

// ---------------- ENDPOINTS CRUD ----------------

// Obtener todos los contratos
app.get('/contratos', (req, res) => {
  db.query('SELECT * FROM CONTRATOS', (err, result) => {
    if (err) return res.status(500).send(err);
    res.json(result);
  });
});

// Obtener contrato por ID
app.get('/contratos/:id', (req, res) => {
  const { id } = req.params;
  db.query('SELECT * FROM CONTRATOS WHERE ID = ?', [id], (err, result) => {
    if (err) return res.status(500).send(err);
    res.json(result[0]);
  });
});

// Crear contrato
app.post('/contratos', (req, res) => {
  const { NOMBRE_CLIENTE, MONTO, FECHA_INICIO, FECHA_FIN, ALCANCE_CONTRATO, ESTADO } = req.body;
  const sql = 'INSERT INTO CONTRATOS (NOMBRE_CLIENTE, MONTO, FECHA_INICIO, FECHA_FIN, ALCANCE_CONTRATO, ESTADO) VALUES (?, ?, ?, ?, ?, ?)';
  db.query(sql, [NOMBRE_CLIENTE, MONTO, FECHA_INICIO, FECHA_FIN, ALCANCE_CONTRATO, ESTADO], (err, result) => {
    if (err) return res.status(500).send(err);
    res.json({ message: 'Contrato creado', id: result.insertId });
  });
});

// Actualizar contrato
app.put('/contratos/:id', (req, res) => {
  const { id } = req.params;
  const { NOMBRE_CLIENTE, MONTO, FECHA_INICIO, FECHA_FIN, ALCANCE_CONTRATO, ESTADO } = req.body;
  const sql = 'UPDATE CONTRATOS SET NOMBRE_CLIENTE=?, MONTO=?, FECHA_INICIO=?, FECHA_FIN=?, ALCANCE_CONTRATO=?, ESTADO=? WHERE ID=?';
  db.query(sql, [NOMBRE_CLIENTE, MONTO, FECHA_INICIO, FECHA_FIN, ALCANCE_CONTRATO, ESTADO, id], (err) => {
    if (err) return res.status(500).send(err);
    res.json({ message: 'Contrato actualizado' });
  });
});

// Eliminar contrato
app.delete('/contratos/:id', (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM CONTRATOS WHERE ID = ?', [id], (err) => {
    if (err) return res.status(500).send(err);
    res.json({ message: 'Contrato eliminado' });
  });
});

// Servidor
app.listen(3000, () => {
  console.log('🚀 Servidor corriendo en http://localhost:3000');
});
