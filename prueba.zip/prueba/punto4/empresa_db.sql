-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-09-2025 a las 01:07:35
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `empresa_db`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `actualizar_salario` (IN `p_dependencia` VARCHAR(255), IN `p_incremento` DECIMAL(5,0))   BEGIN 
    UPDATE empleados
    SET salario = salario * (1 + (p_incremento / 100))
    WHERE dependencia = p_depencencia;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `id_empleado` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `dependencia` varchar(255) DEFAULT NULL,
  `salario` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`id_empleado`, `nombre`, `dependencia`, `salario`) VALUES
(0, 'LEO OSSA', 'ASESOR', 4400),
(1, 'Juan Perez', 'DIRECTIVO', 6050),
(2, 'Julian Pérez', 'ASESOR', 1100),
(3, 'Ana Torres', 'DIRECTIVO', 2200),
(4, 'Carlos Gómez', 'ASESOR', 1650);

--
-- Disparadores `empleados`
--
DELIMITER $$
CREATE TRIGGER `log_cambios_salario` BEFORE UPDATE ON `empleados` FOR EACH ROW BEGIN
    IF OLD.salario <> NEW.salario THEN
        INSERT INTO HISTORIAL_SALARIO_EMPLEADO (id_empleado, salario_anterior, salario_nuevo)
        VALUES (OLD.id_empleado, OLD.salario, NEW.salario);
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial_salario_empleado`
--

CREATE TABLE `historial_salario_empleado` (
  `id` int(11) NOT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `salario_anterior` decimal(15,2) DEFAULT NULL,
  `salario_nuevo` decimal(15,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `historial_salario_empleado`
--

INSERT INTO `historial_salario_empleado` (`id`, `id_empleado`, `fecha`, `salario_anterior`, `salario_nuevo`) VALUES
(1, 0, '2025-09-05 21:56:29', 4000.00, 4400.00),
(2, 1, '2025-09-05 21:56:29', 5500.00, 6050.00),
(3, 2, '2025-09-05 21:56:29', 1000.00, 1100.00),
(4, 3, '2025-09-05 21:56:29', 2000.00, 2200.00),
(5, 4, '2025-09-05 21:56:29', 1500.00, 1650.00);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`id_empleado`);

--
-- Indices de la tabla `historial_salario_empleado`
--
ALTER TABLE `historial_salario_empleado`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `historial_salario_empleado`
--
ALTER TABLE `historial_salario_empleado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
